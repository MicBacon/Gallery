<?php
header('Location: front_controller.php');
exit;
